package com.lsy.test;

import org.aopalliance.intercept.Joinpoint;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyAspect2 {

	@Pointcut("execution(* com.lsy.test.*.*(..))")
	private void myPointCut() {}
	@Before("myPointCut()")
    public void check(JoinPoint joinpoint) {
    	System.out.println("ǰ��֪ͨ��ģ����Ȩ�ޡ���������");
    	System.out.println(joinpoint.getTarget());
    }
	@After("myPointCut()")
    public void log(JoinPoint joinpoint) {
    	System.out.println("����֪ͨ��ģ����־��¼����������");
    	System.out.println(joinpoint.getTarget());
    }
}
