package com.lsy.test;

public interface UserDao {
	public void addUser();

	public void deleteUser();
}
