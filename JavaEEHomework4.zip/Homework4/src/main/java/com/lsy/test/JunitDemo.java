package com.lsy.test;


import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.xml.ConfigurationParser;
import org.mybatis.generator.internal.DefaultShellCallback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lsy.entity.User;
import com.lsy.service.UserService;


@RunWith(SpringJUnit4ClassRunner.class) // ʹ��junit4���в���
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class JunitDemo {
	@Autowired
	private UserService userService;

	@Test
	public void main() throws Exception{
		System.out.println(userService.selectAll());
		User user=new User();
		user.setName("�޻۸�");
		user.setPassword("1234");
		System.out.println(userService.insert(user));
		
		System.out.println(userService.selectAll());
	}
}
