package com.lsy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lsy.dao.UserMapper;
import com.lsy.entity.User;

@Service
public class UserService {
	@Autowired
	private UserMapper userMapper;
	
	public List<User> selectAll(){
		return userMapper.selectAll();
	}
	public int insert(User record) {
		return userMapper.insert(record);
	}
}
