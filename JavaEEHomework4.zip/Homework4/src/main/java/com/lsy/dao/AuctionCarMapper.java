package com.lsy.dao;

import com.lsy.entity.AuctionCar;
import java.util.List;

public interface AuctionCarMapper {
    int insert(AuctionCar record);

    List<AuctionCar> selectAll();
}