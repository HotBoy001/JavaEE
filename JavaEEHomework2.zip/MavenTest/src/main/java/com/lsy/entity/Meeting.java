package com.lsy.entity;

import java.util.List;

public class Meeting {
	private String theme;
	private List<Boss> list;
	public String getTheme() {
		return theme;
	}
	public void setTheme(String theme) {
		this.theme = theme;
	}
	public List<Boss> getList() {
		return list;
	}
	public void setList(List<Boss> list) {
		this.list = list;
	}
	@Override
	public String toString() {
		return "Meeting [theme=" + theme + ", list=" + list + "]";
	}
	

}
