package com.lsy.dao.Imp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.lsy.dao.UserDao;
import com.lsy.entity.User;

@Repository("userDao")
public class UserDaoImp implements UserDao {

	@Override
	public List<User> delUser(List<User> list,int id) {
		// TODO Auto-generated method stub
		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				
				if (list.get(i).getId() == id) {
					list.remove(i);
					break;
				}
			}
		}
		
		System.out.println("test1");
		
		return list;
	}

	@Override
	public void upaUser(List<User> list, User user, int id) {
		// TODO Auto-generated method stub
		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				if (list.get(i).getId() == id) {
					list.set(i, user);
					break;
				}
			}
		}

	}
}
