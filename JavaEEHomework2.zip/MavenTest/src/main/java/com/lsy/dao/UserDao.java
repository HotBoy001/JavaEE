package com.lsy.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.lsy.entity.User;

public interface UserDao {

	public List<User> delUser(List<User> list,int id);
	
	public void upaUser(List<User> list,User user,int id);
}
