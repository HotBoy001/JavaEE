package com.lsy.test;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lsy.entity.Meeting;
import com.lsy.entity.User;
import com.lsy.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class) // ʹ��junit4���в���
@ContextConfiguration(locations = { "classpath:applicationContext.xml" }) // ���������ļ�
public class Demo {
	@Autowired
	private UserService userService;

	@Test
	public void main() {
		List<User> list = new ArrayList<User>();
		list.add(new User(1, "����һ", "��"));
		list.add(new User(2, "���Զ�", "��"));
		list.add(new User(3, "������", "��"));
		System.out.println(list);
		System.out.println(userService.delUser(list, 1));
	}

	// @Test
	// public void deltest() {
	//
	// List<User> list= new ArrayList<User>();
	// list.add(new User(1,"����һ","��"));
	// list.add(new User(2,"���Զ�","��"));
	// list.add(new User(3,"������","��"));
	// System.out.println(list);
	// userService.delUser(list,1);
	// System.out.println(list);
	// }
	//
	@Test
	public void upatest() {
		List<User> list = new ArrayList<User>();
		list.add(new User(1, "����һ", "��"));
		list.add(new User(2, "���Զ�", "��"));
		list.add(new User(3, "������", "��"));

		System.out.println(list);
		userService.upaUser(list, new User(2, "������", "Ů"), 2);
		System.out.println(list);
	}

	@Test
	public void meetingDemo() {
		ApplicationContext ac = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        Meeting meeting=(Meeting) ac.getBean("meeting");
        System.out.println(meeting);
	}
}
