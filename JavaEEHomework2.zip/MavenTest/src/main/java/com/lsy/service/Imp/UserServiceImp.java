package com.lsy.service.Imp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lsy.dao.UserDao;
import com.lsy.entity.User;
import com.lsy.service.UserService;

@Service("userService")
public class UserServiceImp implements UserService {
	
    @Resource
	UserDao userDao;

	@Override
	public List<User> delUser(List<User> list,int id) {
		// TODO Auto-generated method stub
		return userDao.delUser(list,id);
	}

	@Override
	public void upaUser(List<User> list, User user, int id) {
		// TODO Auto-generated method stub
		userDao.upaUser(list, user, id);
	}

}
