package com.lsy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lsy.entity.User;

  
  public interface UserService {
	
	public List<User> delUser(List<User> list,int id);

	public void upaUser(List<User> list, User user, int id);
}

